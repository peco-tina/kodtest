package com.infrasight.kodtest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import com.google.gson.Gson;
import model.Account;
import model.GroupMember;
import org.junit.Test;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;

/**
 * Simple concrete class for JUnit tests with uses {@link TestsSetup} as a
 * foundation for starting/stopping the API server for tests.
 * 
 * You may configure port, api user and api port in {@link TestVariables} if
 * needed.
 */
public class Tests extends TestsSetup {

	/**
	 * Simple example test which asserts that the Kodtest API is up and running.
	 */
	@Test
	public void connectionTest() throws InterruptedException {
		assertTrue(serverUp);
	}

	@Test
	public void assignment1() throws InterruptedException {
		assertTrue(serverUp);
		String firstName = "Vera";
		String lastName = "Scope";
		String employeeId = "1337";
		String finalToken = getToken();

		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("http://localhost:8080/api/accounts?filter=employeeId%3D1337"))
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.setHeader("Authorization", "Bearer " + finalToken)
				.build();
		HttpResponse<String> response = null;
		try {
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		} catch (IOException e) {
			e.printStackTrace();
		}

		String json = response.body();
		Account account;
		Gson gson = new Gson();
		Account accounts[] = gson.fromJson(json, Account[].class);

		account = accounts[0];
		assertEquals(account.getEmployeeId(), employeeId);
		assertEquals(account.getFirstName(), firstName);
		assertEquals(account.getLastName(), lastName);
	}

	@Test
	public void assignment2() throws InterruptedException {
		assertTrue(serverUp);
		String finalToken = getToken();
		String json;
		Gson gson = new Gson();
		String memberId = "vera_scope";

		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("http://localhost:8080/api/relationships?filter=memberId%3Dvera_scope"))
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.setHeader("Authorization", "Bearer " + finalToken)
				.build();
		HttpResponse<String> response = null;
		try {
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		} catch (IOException e) {
			e.printStackTrace();
		}

		json = response.body();
		GroupMember groups[] = gson.fromJson(json, GroupMember[].class);

		int groupCount = groups.length;
		String gruppKopenhamnId = "grp_köpenhamn";
		String gruppMalmloId = "grp_malmo";
		String gruppKonsultId = "grp_itkonsulter";

		// Assert which verifies the expected group count of 3
		assertEquals(3, groupCount);
		assertTrue(groups[0].getGroupId().equals(gruppKopenhamnId) || groups[0].getGroupId().equals(gruppMalmloId)
				|| groups[0].getGroupId().equals(gruppKonsultId));
		assertTrue(groups[1].getGroupId().equals(gruppKopenhamnId) || groups[1].getGroupId().equals(gruppMalmloId)
				|| groups[1].getGroupId().equals(gruppKonsultId));
		assertTrue(groups[2].getGroupId().equals(gruppKopenhamnId) || groups[2].getGroupId().equals(gruppMalmloId)
				|| groups[2].getGroupId().equals(gruppKonsultId));
	}

	@Test
	public void assignment3() throws InterruptedException {
		assertTrue(serverUp);
		String finalToken = getToken();
		String[] groupIds = {"grp_köpenhamn", "grp_malmo", "grp_itkonsulter"};
		String httpRequest = "http://localhost:8080/api/relationships?skip=0&filter=memberId%3D";
		List<String> allGroupsId = new ArrayList<>();
		HttpRequest request = null;
		HttpResponse<String> response = null;
		Gson gson = new Gson();
		String json;
		int j = 0;
		int expectedNumberOfGroups = 9;

		for (int i = 0; i < groupIds.length; i++) {
			if (!allGroupsId.contains(groupIds[i])) {
				allGroupsId.add(groupIds[i]);
			}

			boolean fetchedAllGroups = false;
			boolean isEmptyResponse = false;

			while (!fetchedAllGroups || !isEmptyResponse) {
				String s = null;
				StringBuilder sb = new StringBuilder(httpRequest);
				sb.append(allGroupsId.get(j));
				s = sb.toString();

				request = HttpRequest.newBuilder()
						.uri(URI.create(s))
						.method("GET", HttpRequest.BodyPublishers.noBody())
						.setHeader("Authorization", "Bearer " + finalToken)
						.build();
				try {
					response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (response.body().equals("[]")) {
					isEmptyResponse = true;
					j++;
					break;
				}
				json = response.body();
				GroupMember groupsFromResponse[] = gson.fromJson(json, GroupMember[].class);
				if (allGroupsId.contains(groupsFromResponse[0].getGroupId())) {
					fetchedAllGroups = true;
					j++;
					break;
				}
				allGroupsId.add(groupsFromResponse[0].getGroupId());
				j++;
			}
		}
		assertEquals(allGroupsId.size(), expectedNumberOfGroups);
		assertTrue(allGroupsId.contains(groupIds[0]) && allGroupsId.contains(groupIds[1])
				&& allGroupsId.contains(groupIds[2]) && allGroupsId.contains("grp_danmark")
				&& allGroupsId.contains("grp_sverige") && allGroupsId.contains("grp_inhyrda")
				&& allGroupsId.contains("grp_chokladfabrik") && allGroupsId.contains("grp_choklad")
				&& allGroupsId.contains("grp_konfektyr"));
	}

	@Test
	public void assignment4() throws InterruptedException {
		assertTrue(serverUp);
		String finalToken = getToken();
		long skip = 0l;
		String dkk = "DKK";
		String sek = "SEK";
		String eur = "EUR";
		Long totalDkk = 0l;
		Long totalSek = 0l;
		Long totalEur = 0l;
		String httpRequest = "http://localhost:8080/api/relationships?skip=";
		String addFilter = "&filter=groupId%3Dgrp_inhyrda";
		List<String> memberIds = new ArrayList<>();
		List<Account> accounts = new ArrayList<>();

		memberIds.addAll(fetchAllMember(httpRequest, skip, addFilter, finalToken));

		while(findGroupAsMember(memberIds) != null){
			skip = 0l;
			String filter = "&filter=groupId%3D";
			String id = findGroupAsMember(memberIds);
			if(!isVera(id)) {
				memberIds.remove(id);
			}
			filter += id;
			if(!isVera(id)) {
				memberIds.addAll(fetchAllMember(httpRequest, skip, filter, finalToken));
			}
			if(isVera(id)){
				break;
			}
		}

		accounts.addAll(fetchAllAccounts(memberIds, false));

		for(Account account : accounts){
			if(account.getSalaryCurrency().equals(sek)){
				totalSek += account.getSalary();
			} else if (account.getSalaryCurrency().equals(dkk)){
				totalDkk += account.getSalary();
			} else if(account.getSalaryCurrency().equals(eur)){
				totalEur += account.getSalary();
			}
		}
		Long sekExpected = 16718313l;
		Long dkkExpected = 2007822l;
		Long eurExpected = 552997l;

		assertEquals(sekExpected, totalSek);
		assertEquals(dkkExpected, totalDkk);
		assertEquals(eurExpected, totalEur);
	}

	@Test
	public void assignment5() throws InterruptedException {
		assertTrue(serverUp);
		String finalToken = getToken();
		String gruppSverigeId = "grp_sverige";
		HttpRequest request;
		HttpResponse<String> response = null;
		String json;
		Gson gson;
		List<String> allaSaljare = new ArrayList<>();
		List<String> allaChefer = new ArrayList<>();

		request = HttpRequest.newBuilder()
				.uri(URI.create("http://localhost:8080/api/relationships?filter=groupId%3Dgrp_sverige"))
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.setHeader("Authorization", "Bearer " + finalToken)
				.build();
		try {
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		} catch (IOException e) {
			e.printStackTrace();
		}

		json = response.body();
		gson = new Gson();
		GroupMember members[] = gson.fromJson(json, GroupMember[].class);

		List<String> gruppMalmo = new ArrayList<>();
		List<String> gruppGoteborg = new ArrayList<>();
		List<String> gruppStockholm = new ArrayList<>();

		String httpLink = "http://localhost:8080/api/relationships?skip=";
		Long skip = 0l;

		for(int i = 0; i < members.length; i++){
			String filter = "&filter=groupId%3D";
			filter += members[i].getMemberId();

			if(members[i].getMemberId().equals("grp_malmo")){
				gruppMalmo.addAll(fetchAllMember(httpLink, skip, filter, finalToken));
			}
			if(members[i].getMemberId().equals("grp_goteborg")) {
				gruppGoteborg.addAll(fetchAllMember(httpLink, skip, filter, finalToken));
			}
			if(members[i].getMemberId().equals("grp_stockholm")) {
				gruppStockholm.addAll(fetchAllMember(httpLink, skip, filter, finalToken));
			}
		}

		String filterSaljare = "&filter=groupId%3Dgrp_saljare";
		allaSaljare.addAll(fetchAllMember(httpLink, skip, filterSaljare, finalToken));

		List<String> malmoSaljare = new ArrayList<>();
		List<String> goteborgSaljare = new ArrayList<>();
		List<String> stockholmSaljare = new ArrayList<>();

		malmoSaljare.addAll(getMemberByCity(allaSaljare, gruppMalmo));
		goteborgSaljare.addAll(getMemberByCity(allaSaljare, gruppGoteborg));
		stockholmSaljare.addAll(getMemberByCity(allaSaljare, gruppStockholm));

		List<Account> malmoSaljareAcc = new ArrayList<>();
		List<Account> goteborgSaljareAcc = new ArrayList<>();
		List<Account> stockholmSaljareAcc = new ArrayList<>();

		malmoSaljareAcc.addAll(fetchAllAccounts(malmoSaljare, true));
		goteborgSaljareAcc.addAll(fetchAllAccounts(goteborgSaljare, true));
		stockholmSaljareAcc.addAll(fetchAllAccounts(stockholmSaljare, true));

		String filterChefer = "&filter=groupId%3Dgrp_chefer";
		allaChefer.addAll(fetchAllMember(httpLink, skip, filterChefer, finalToken));

		List<String> malmoChefer = new ArrayList<>();
		List<String> goteborgChefer = new ArrayList<>();
		List<String> stockholmChefer = new ArrayList<>();

		malmoChefer.addAll(getMemberByCity(allaChefer, gruppMalmo));
		goteborgChefer.addAll(getMemberByCity(allaChefer, gruppGoteborg));
		stockholmChefer.addAll(getMemberByCity(allaChefer, gruppStockholm));

		List<String> cheferSorterad = new ArrayList<>();

		int malmoSaljareCount = malmoSaljareAcc.size();
		int stockholmSaljareCount = stockholmSaljareAcc.size();
		int goteborgSaljareCount = goteborgSaljareAcc.size();

		while (true){
			if(malmoSaljareCount >= stockholmSaljareCount && malmoSaljareCount >= goteborgSaljareCount){
				if(malmoSaljareCount > 0) {
					cheferSorterad.addAll(malmoChefer);
					malmoSaljareCount = 0;
				}
			}
			if(goteborgSaljareCount >= stockholmSaljareCount && goteborgSaljareCount >= malmoSaljareCount){
				if(goteborgSaljareCount > 0) {
					cheferSorterad.addAll(goteborgChefer);
					goteborgSaljareCount = 0;
				}
			}
			if(stockholmSaljareCount >= goteborgSaljareCount && stockholmSaljareCount >= malmoSaljareCount){
				if(stockholmSaljareCount > 0) {
					cheferSorterad.addAll(stockholmChefer);
					stockholmSaljareCount = 0;
				}
			}
			if(malmoSaljareCount == 0 && stockholmSaljareCount == 0 && goteborgSaljareCount == 0) {
				break;
			}
		}

		List<Account> chefer = new ArrayList<>();
		chefer.addAll(fetchAllAccounts(cheferSorterad, false));

		assertEquals(malmoChefer.size(), 3);
		assertEquals(goteborgChefer.size(), 3);
		assertEquals(stockholmChefer.size(), 3);

		assertEquals(malmoSaljareAcc.size(), 21);
		assertEquals(goteborgSaljareAcc.size(), 4);
		assertEquals(stockholmSaljareAcc.size(), 5);

		assertEquals(chefer.get(8).getFirstName(), "Emelie");
		assertEquals(chefer.get(8).getLastName(), "Gustavsson");
	}

	private Collection<String> getMemberByCity(List<String> allMember, List<String> groupCity) {
		List<String> id = new ArrayList<>();
		id.addAll(groupCity);
		id.retainAll(allMember);
		return id;
	}

	public String getToken() {
		String token;
		String credentials = "{\n" +
				"  \"user\": \"apiUser\",\n" +
				"  \"password\": \"apiPassword\"\n" +
				"}";
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("http://localhost:8080/api/auth"))
				.header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(credentials))
				.build();
		HttpResponse<String> response = null;
		try {
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		};
		token = response.body().substring(10, 58);
		return token;
	}

	private boolean isVera(String id) {
		return id.equals("vera_scope");
	}

	private Collection<String> fetchAllMember(String httpRequest, Long skip, String addFilter, String finalToken) {
		boolean fetchedAllMembers = false;
		HttpRequest request = null;
		HttpResponse<String> response = null;
		Gson gson = new Gson();
		String json;
		List<String> memberIds = new ArrayList<>();

		while(!fetchedAllMembers){
			String s;
			StringBuilder sb = new StringBuilder(httpRequest);
			sb.append(skip);
			sb.append(addFilter);
			s = sb.toString();

			request = HttpRequest.newBuilder()
					.uri(URI.create(s))
					.method("GET", HttpRequest.BodyPublishers.noBody())
					.setHeader("Authorization", "Bearer " + finalToken)
					.build();
			try {
				response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
			if(response.body().equals("[]")){
				fetchedAllMembers = true;
				break;
			}
			json = response.body();
			GroupMember membersFromResponse[] = gson.fromJson(json, GroupMember[].class);

			for(int i = 0; i < membersFromResponse.length; i++){
				memberIds.add(membersFromResponse[i].getMemberId());
			}
			skip += 50l;
		}
		return memberIds;
	}


	private String findGroupAsMember(List<String> memberIds) {
		for(String s : memberIds){
			if(!s.substring(0,3).equals("acc")){
				return  s;
			}
		}
		return null;
	}

	private Collection<? extends Account> fetchAllAccounts(List<String> memberIds, boolean shouldCheckForDate) {
		String finalToken = getToken();
		List<Account> accounts = new ArrayList<>();
		String requestString = "http://localhost:8080/api/accounts?filter=id%3D";
		HttpRequest request;
		HttpResponse<String> response = null;
		String json;
		Gson gson;

		Long firstaStartDate = 1546297200l;
		Long lastStartDate = 1672527599l;

		for (String memberId : memberIds) {
			String query;
			StringBuilder sb = new StringBuilder(requestString);
			sb.append(memberId);
			query = sb.toString();

			request = HttpRequest.newBuilder()
					.uri(URI.create(query))
					.method("GET", HttpRequest.BodyPublishers.noBody())
					.setHeader("Authorization", "Bearer " + finalToken)
					.build();
			try {
				response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
			json = response.body();
			gson = new Gson();
			Account acc[] = gson.fromJson(json, Account[].class);
			Account account = acc[0];

			if (shouldCheckForDate) {
				if (account.getEmployedSince() >= firstaStartDate && account.getEmployedSince() <= lastStartDate) {
					accounts.add(acc[0]);
				}
			} else {
				accounts.add(acc[0]);
			}
		}
		return accounts;
	}
}